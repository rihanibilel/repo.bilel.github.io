﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from hashlib import new
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress
from resources.lib.parser import cParser
import base64
import sys

import requests,re
sgn = requests.Session()

from codequick import Route, Resolver, Listitem
import urlquick

SITE= 'https://www.tv96.tv'
SITE_NAME = 'tv96'

@Route.register
def init_tvnine(plugin, content_type="segment"):
    oRequestHandler = cRequestHandler(SITE)
    sHtmlContent = oRequestHandler.request()

    # ([^<]+) .+? (.+?)

    sPattern = '<div class="containerMatch"><a href="(.+?)" target=.+?<div style="font-weight: bold">(.+?)</div>.+?<div class="matchTime">(.+?)</div>.+?<div style="font-weight: bold">(.+?)</div>'



    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)


    if (aResult[0] == True):
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            sTitle =  aEntry[1]+' vs '+aEntry[3]
            sThumbnail = ""
            siteUrl = aEntry[0]
            sInfo = aEntry[2]
            item = Listitem()
            item.label = sTitle + '( ' +sInfo+ ')'
            item.art.thumb = sThumbnail
            item.art.fanart = sThumbnail
            item.set_callback(extract_source,siteUrl,item.label)
            yield item
        
        progress_.VSclose(progress_)

  


@Resolver.register
def extract_source(plugin, url, title):
    
    oRequestHandler = cRequestHandler(url)
    sHtmlContent = oRequestHandler.request()
    oParser = cParser()

    # (.+?) # ([^<]+) .+? 
    sPattern = 'data-embed="(.+?)">(.+?)</li>'
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    #import web_pdb;web_pdb.set_trace()
    links = []
    #print aResult
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            sTitle = aEntry[1]
            siteUrl = aEntry[0]
            sInfo = ''
            oRequestHandler = cRequestHandler(siteUrl)
            data = oRequestHandler.request()
            oParser = cParser()
    # (.+?) # ([^<]+) .+? 
            sPattern = 'source: "(.+?)",'
            aResult = oParser.parse(data, sPattern)
            if (aResult[0] == True):
               for aEntry in aResult[1]:
                url = aEntry
                if url.startswith('//'):
                      url = 'https:' + url 
                sHosterUrl = url.replace("https://tv.hd44.net/p/phone.html?src=","") 
                sHosterUrl = sHosterUrl+ '|User-Agent=Android'
                sMovieTitle = sTitle
                item = {"label": sMovieTitle, "link": sHosterUrl, "name": sMovieTitle}
                links.append(item)
    # (.+?) # ([^<]+) .+? 
            sPattern = 'src="(.+?)"'
            aResult = oParser.parse(data, sPattern)
            if (aResult[0] == True):
               for aEntry in aResult[1]:
            
                   url = aEntry
                   if url.startswith('//'):
                      url = 'https:' + url
                   sHosterUrl = url.replace("https://tv.hd44.net/p/phone.html?src=","") 
                   sHosterUrl = sHosterUrl+ '|User-Agent=Android' 
                   sMovieTitle = sTitle
                   
                   item = {"label": sMovieTitle, "link": sHosterUrl, "name": sMovieTitle}
                   links.append(item)
    # (.+?) # ([^<]+) .+? 
            sPattern = "hls: '(.+?)'"
            aResult = oParser.parse(data, sPattern)
            if (aResult[0] == True):
               for aEntry in aResult[1]:
            
                   url = aEntry
                   if url.startswith('//'):
                      url = 'https:' + url
                   sHosterUrl = url.replace("https://tv.hd44.net/p/phone.html?src=","") 
                   sHosterUrl = sHosterUrl+ '|User-Agent=Android' 
                   sMovieTitle = sTitle
            
                   item = {"label": sMovieTitle, "link": sHosterUrl, "name": sMovieTitle}
                   links.append(item)
    # (.+?) # ([^<]+) .+? 
            sPattern = 'file: "(.+?)",'
            aResult = oParser.parse(data, sPattern)
            if (aResult[0] == True):
               for aEntry in aResult[1]:
            
                   url = aEntry
                   if url.startswith('//'):
                      url = 'https:' + url
                   sHosterUrl = url.replace("https://tv.hd44.net/p/phone.html?src=","") 
                   sHosterUrl = sHosterUrl+ '|User-Agent=Android' 
                   sMovieTitle = sTitle
            
                   item = {"label": sMovieTitle, "link": sHosterUrl, "name": sMovieTitle}
                   links.append(item)
    # (.+?) # ([^<]+) .+? 
            sPattern = '<iframe src=".+?stream_url=(.+?)" height'
            aResult = oParser.parse(data, sPattern)
            UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Mobile Safari/537.36'
            if (aResult[0] == True):
               for aEntry in aResult[1]:
            
                   url = aEntry
                   if url.startswith('//'):
                      url = 'https:' + url
                   sHosterUrl = url.replace("https://tv.hd44.net/p/phone.html?src=","") 
                   sHosterUrl = sHosterUrl+ '|User-Agent=' + UA + '&Referer=https://yastatic.net/' 
                   sMovieTitle = sTitle
            
                   item = {"label": sMovieTitle, "link": sHosterUrl, "name": sMovieTitle}
                   links.append(item)  
    

    import xbmcgui
    result = xbmcgui.Dialog().select('Choose source :', [source["label"] if source else 'Uknown' for source in links])
    url = links[result]["link"]
    return Listitem().from_dict(**{
        "label" : "Playing:" + links[result]["name"],
        "callback": url
    })
    return plugin.extract_source(sHosterUrl)
