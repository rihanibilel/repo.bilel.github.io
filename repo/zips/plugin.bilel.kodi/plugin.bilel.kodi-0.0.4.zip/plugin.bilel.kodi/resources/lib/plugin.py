from __future__ import unicode_literals
from hashlib import new

from codequick import Route, Listitem,run
from resources.sites import akoam, egybest, sports

#import web_pdb;web_pdb.set_trace()

@Route.register
def root(plugin, content_type="segment"):
    art = 'https://i.pinimg.com/736x/ca/bf/a8/cabfa8c188d16ecda76a846ec98efb23.jpg'
    item = {"label": "AKOAM", "art": {"thumb":art}, "callback": akoam.initAkoam}
    yield Listitem.from_dict(**item)

    art = 'https://lh3.googleusercontent.com/t4i_YBOdUoEcS_H8dS02qFp0ir69ZJECzsPJcWkO4gZC48KuN1UUdOGQyY_Z1_Zz0_Re=w220'
    item = {"label": "EGY.BEST", "art": {"thumb":art}, "callback": egybest.initEgybest}
    yield Listitem.from_dict(**item)

    art = 'https://proxies.bein-mena-production.eu-west-2.tuc.red/proxy/imgdata?objectId=9_1846588275&format_w=1024&format_h=600&ratio=43&type=link&languageId=ara'
    item = {"label": "SPORTS", "art": {"thumb":art}, "callback": sports.initSports}
    yield Listitem.from_dict(**item)
