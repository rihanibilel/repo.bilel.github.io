import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.bilel.kodi/?site=cViewing&function=delViewingMenu)", True)
