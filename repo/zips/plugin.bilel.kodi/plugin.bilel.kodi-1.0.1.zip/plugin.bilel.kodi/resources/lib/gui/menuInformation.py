import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.bilel.kodi/?site=cGui&function=viewInfo)", True)
