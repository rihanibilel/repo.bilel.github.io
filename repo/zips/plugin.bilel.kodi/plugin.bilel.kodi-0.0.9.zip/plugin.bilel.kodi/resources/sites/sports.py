# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from hashlib import new

from codequick import Route, Listitem
import urlquick
from resources.sites import tvnine, asgoal, beinsports_net, kingfoot

@Route.register
def initSports(plugin, content_type="segment"):
    art = 'https://assets.bein.com/mena/sites/4/2015/06/bein-Logo.png'
    item = {"label": "RESUME", "art": {"thumb":art}, "callback": beinsports_net.init_beinsport}
    yield Listitem.from_dict(**item)

    art = 'https://3.bp.blogspot.com/-SD3IBeaaGUI/XzFKmkr1gOI/AAAAAAAAAMk/PytapmqqdFE2BjvcwvGqv5EqSq2f-YeFwCK4BGAYYCw/s1600/tv96.png'
    item = {"label": "TV96*BETA", "art": {"thumb":art}, "callback": tvnine.init_tvnine}
    yield Listitem.from_dict(**item)

    art = 'https://www.as-goal.com/wp-content/themes/as-goal/img/logo.png'
    item = {"label": "ASGOAL*BETA", "art": {"thumb":art}, "callback": asgoal.init_asgoal}
    yield Listitem.from_dict(**item)

    art = 'https://i.pinimg.com/originals/89/98/76/899876958925e65fd90ac8fdb459d7c8.png'
    item = {"label": "KINGFOOT*BETA", "art": {"thumb":art}, "callback": kingfoot.init_kingfoot}
    yield Listitem.from_dict(**item)


