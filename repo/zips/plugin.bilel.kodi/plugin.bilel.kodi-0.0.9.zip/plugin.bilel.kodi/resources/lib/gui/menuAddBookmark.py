import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.bilel.kodi/?site=cFav&function=setBookmark)", True)
