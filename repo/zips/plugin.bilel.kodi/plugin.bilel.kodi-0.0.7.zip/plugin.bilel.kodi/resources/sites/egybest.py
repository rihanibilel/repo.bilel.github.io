# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from hashlib import new
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.parser import cParser
import base64
import sys

import requests,re
sgn = requests.Session()

from codequick import Route, Resolver, Listitem
import urlquick

SITE= 'https://giga.egybest.ink'

@Route.register
def initEgybest(plugin, content_type="segment"):
   yield Listitem.recent(recent_videos, url=SITE+"/trending/")
   yield Listitem.search(search_videos)
   
   art = 'https://lh3.googleusercontent.com/t4i_YBOdUoEcS_H8dS02qFp0ir69ZJECzsPJcWkO4gZC48KuN1UUdOGQyY_Z1_Zz0_Re=w220'
   item = {"label": "Films", "art": {"thumb":art}, "callback": getInitfilm}
   yield Listitem.from_dict(**item)

   item = {"label": "Series", "art": {"thumb": art}, "callback": getInitfilm, "params":{"type":'series'}}
   yield Listitem.from_dict(**item)

@Route.register
def recent_videos(_, url, filter_mode=0):
    resp = urlquick.get(url, max_age=-1)
    filmListRoot = resp.parse("div", attrs={"class":"movies"})
    filmLinks = filmListRoot.iterfind("a")
    #import web_pdb;web_pdb.set_trace()
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("src")
            item.art.fanart = image.get("src")
            item.set_callback(extract_source,tempLink,item.label )
            yield item
    


@Route.register
def search_videos(plugin, search_query):
    url = (SITE+"/explore/?q={}".format(search_query))
    return video_list(plugin, url)


@Route.register
def video_list(_, url, filter_mode=0):
    resp = urlquick.get(url)
    filmListRoot = resp.parse("div", attrs={"class":"movies"})
    filmLinks = filmListRoot.iterfind("a")
    #import web_pdb;web_pdb.set_trace()
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("src")
            item.art.fanart = image.get("src")
            if tempLink.__contains__('series'):
                item.set_callback(getSeriesSeason,tempLink)
            else:
                item.set_callback(extract_source,tempLink, item.label)
            yield item
    
    

@Route.register
def getInitfilm(plugin, type="film"):
    url = SITE
    if (type=='series'):
        resp = urlquick.get(url+ '/series/', max_age=-1)
    else:
        resp = urlquick.get(url+ '/movies/', max_age=-1)
    filmListRoot = resp.parse("div", attrs={"class":"movies"})
    filmLinks = filmListRoot.iterfind("a")
    #import web_pdb;web_pdb.set_trace()
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("src")
            item.art.fanart = image.get("src")
            if (type=='series'):
                item.set_callback(getSeriesSeason,tempLink)
            else :
                item.set_callback(extract_source,tempLink,item.label)
            yield item
    

@Route.register
def getSeriesSeason(plugin, url):
    oRequestHandler = cRequestHandler(url)
    sHtmlContent = oRequestHandler.request()
  # ([^<]+) .+?
    sPattern = '<a href="([^<]+)" class="movie">.+?src="([^<]+)" alt=".+?"> <span class="title">([^<]+)</span>'

    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
	
	
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            item = Listitem()
            sTitle =  aEntry[2].replace("مشاهدة","").replace("الأخيرة","").replace("مسلسل","").replace("انمي","").replace("مترجمة","").replace("الاخيرة","").replace("مترجم","").replace(" الحادي عشر","11").replace(" الثاني عشر","12").replace(" الثالث عشر","13").replace(" الرابع عشر","14").replace(" الخامس عشر","15").replace(" السادس عشر","16").replace(" السابع عشر","17").replace(" الثامن عشر","18").replace(" التاسع عشر","19").replace(" العشرون","20").replace(" الحادي و العشرون","21").replace(" الثاني و العشرون","22").replace(" الثالث و العشرون","23").replace(" الرابع والعشرون","24").replace(" الخامس و العشرون","25").replace(" السادس والعشرون","26").replace(" السابع والعشرون","27").replace(" الثامن والعشرون","28").replace(" التاسع والعشرون","29").replace(" الثلاثون","30").replace(" الحادي و الثلاثون","31").replace(" الثاني والثلاثون","32").replace(" الاول","1").replace(" الثاني","2").replace(" الثانى","2").replace(" الثالث","3").replace(" الرابع","4").replace(" الخامس","5").replace(" السادس","6").replace(" السابع","7").replace(" الثامن","8").replace(" التاسع","9").replace(" العاشر","10").replace("الموسم","S")
            siteUrl = aEntry[0]
            sThumbnail = aEntry[1]
            sInfo = ''
            if sThumbnail.startswith('//'):
                sThumbnail = "https:"+aEntry[1]
            
            item.label = sTitle
            item.art.thumb = sThumbnail
            item.art.fanart = sThumbnail
            item.set_callback(getSeriesEpisodes,siteUrl,sThumbnail, item.label)
            yield item

@Route.register
def getSeriesEpisodes(plugin, url,sThumbnail,seasonName):
    oRequestHandler = cRequestHandler(url)
    sHtmlContent = oRequestHandler.request()
        
  # ([^<]+) .+?
    sPattern = '<a href="([^<]+)" class="movie"> <img src="([^<]+)"> <span class="title">([^<]+)</span>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
	
	
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            item = Listitem()
            sTitle = aEntry[2].replace(" العاشر","10").replace(" الحادي عشر","11").replace(" الثاني عشر","12").replace(" الثالث عشر","13").replace(" الرابع عشر","14").replace(" الخامس عشر","15").replace(" السادس عشر","16").replace(" السابع عشر","17").replace(" الثامن عشر","18").replace(" التاسع عشر","19").replace(" العشرون","20").replace(" الحادي و العشرون","21").replace(" الثاني و العشرون","22").replace(" الثالث و العشرون","23").replace(" الرابع والعشرون","24").replace(" الخامس و العشرون","25").replace(" السادس والعشرون","26").replace(" السابع والعشرون","27").replace(" الثامن والعشرون","28").replace(" التاسع والعشرون","29").replace(" الثلاثون","30").replace(" الحادي و الثلاثون","31").replace(" الثاني والثلاثون","32").replace(" الاول","1").replace(" الثاني","2").replace(" الثانى","2").replace(" الثالث","3").replace(" الرابع","4").replace(" الخامس","5").replace(" السادس","6").replace(" السابع","7").replace(" الثامن","8").replace(" التاسع","9").replace("الموسم","S").replace("(الاخيرة)","").split('الحلقة')[-1].replace("ى","").replace("ة","").replace("E ","E")
            sTitle = 'E'+sTitle
            sTitle = sTitle.replace("E ","E")
            siteUrl = aEntry[0]
            sThumbnail = str(sThumbnail)
            sInfo = ''
            item.label = sTitle
            item.art.thumb = sThumbnail
            item.art.fanart = sThumbnail
            item.set_callback(extract_source,siteUrl,seasonName +"-" + item.label)
            yield item
        
  # ([^<]+) .+?
    sPattern = '<a href="([^<]+)" class="movie"><span class="r"><i class="i-fav rating"><i>.+?</i></i></span> <img src="([^<]+)"> <span class="title">([^<]+)</span>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
	
	
    if (aResult[0] == True):
        item = Listitem()
        for aEntry in aResult[1]:
 
            sTitle = ' E'+aEntry[2].replace(" العاشر","10").replace(" الحادي عشر","11").replace(" الثاني عشر","12").replace(" الثالث عشر","13").replace(" الرابع عشر","14").replace(" الخامس عشر","15").replace(" السادس عشر","16").replace(" السابع عشر","17").replace(" الثامن عشر","18").replace(" التاسع عشر","19").replace(" العشرون","20").replace(" الحادي و العشرون","21").replace(" الثاني و العشرون","22").replace(" الثالث و العشرون","23").replace(" الرابع والعشرون","24").replace(" الخامس و العشرون","25").replace(" السادس والعشرون","26").replace(" السابع والعشرون","27").replace(" الثامن والعشرون","28").replace(" التاسع والعشرون","29").replace(" الثلاثون","30").replace(" الحادي و الثلاثون","31").replace(" الثاني والثلاثون","32").replace(" الاول","1").replace(" الثاني","2").replace(" الثانى","2").replace(" الثالث","3").replace(" الرابع","4").replace(" الخامس","5").replace(" السادس","6").replace(" السابع","7").replace(" الثامن","8").replace(" التاسع","9").replace("(الاخيرة)","").replace("الموسم","S").split('الحلقة')[-1].replace("ى","").replace("ة","").replace("E ","E")
            sTitle = sTitle.replace("E ","E")
            siteUrl = aEntry[0]
            sThumbnail = sThumbnail
            sInfo = ''
            item.label = sTitle
            item.art.thumb = sThumbnail
            item.art.fanart = sThumbnail
            item.set_callback(extract_source,siteUrl,seasonName +"-" + item.label)
            yield item

@Resolver.register
def extract_source(plugin, url, title):
    
    oRequestHandler = cRequestHandler(url)
    sHtmlContent = oRequestHandler.request()
    MLisTe = []
    host = url.split('//')[1].split('/')[0]
    url = url+"#download"
    rgx = '<iframe class="auto-size" src="(.+?)"'
    tmx = '<td class="tar">.+?dl _open_window" data-url="(.+?)"'
    data = sgn.get(url).content.decode('utf-8')
    link = "https://"+host+re.findall(rgx,data)[0]
    _tar = re.findall(tmx,data)
    for href in _tar:
        href = "https://"+host+href
        MLisTe.append((href))
    bimbo = MLisTe[0]
    data =  sgn.get(link).content.decode('utf-8')
    scrtp  = get_Scripto(data)
    ln1,ln2,prm = VidStream(scrtp)
    ln1 = "https://"+host+ln1
    ln2 = "https://"+host+ln2
    sgn.get(ln1)
    T = sgn.post(ln2,data=prm).content.decode('utf-8')
   
    if T == 'ok':
        data = sgn.get(link).content.decode('utf-8')
        sPattern = '<source src="(.+?)" type="application/x-mpegURL">'
        oParser = cParser()
        aResult = oParser.parse(data, sPattern)
        if (aResult[0] == True):
            for aEntry in aResult[1]:
                kurl = "https://tool.egybest.ltd"+aEntry
                #sTitle =  sMovieTitle
                sHosterUrl = kurl
    
    return Listitem().from_dict(**{
        "label" : "Playing: " + title,
        "callback": sHosterUrl
    })
    return plugin.extract_source(sHosterUrl)


def get_Scripto(data):
    script = ''
    scrtp = re.findall("<script.*?>(.*?)</script>", data, re.S)
    for s in scrtp:
        if '(){ var' in s:
            #print s
            return s

def decal(tab,step,step2,decal_fnc):
    decal_fnc = decal_fnc.replace('var ','global d; ')  
    decal_fnc = decal_fnc.replace('x(','x(tab,step2,') 
    exec(decal_fnc)
    aa=0
    while True:
        aa=aa+1
        tab.append(tab[0])
        del tab[0]
        #print([i for i in tab[0:10]])
        exec(decal_fnc) 
        #print(str(aa)+':'+str(c))
        if ((d == step) or (aa>10000)): break
       
def VidStream(script):
    tmp = re.findall('var.*?=(.{2,4})\(\)', script, re.S)
    if not tmp: return 'ERR:Varconst Not Found'
    varconst = tmp[0].strip()
    print('Varconst     = %s' % varconst)
    tmp = re.findall('}\('+varconst+'?,(0x[0-9a-f]{1,10})\)\);', script)
    if not tmp: return 'ERR:Step1 Not Found'
    step = eval(tmp[0])
    print('Step1        = 0x%s' % '{:02X}'.format(step).lower())
    tmp = re.findall('d=d-(0x[0-9a-f]{1,10});', script)
    if not tmp: return 'ERR:Step2 Not Found'
    step2 = eval(tmp[0])
    print('Step2        = 0x%s' % '{:02X}'.format(step2).lower())    
    tmp = re.findall("try{(var.*?);", script)
    if not tmp: return 'ERR:decal_fnc Not Found'
    decal_fnc = tmp[0]
    print('Decal func   = " %s..."' % decal_fnc[0:135])
    tmp = re.findall("'data':{'(_[0-9a-zA-Z]{10,20})':'ok'", script)
    if not tmp: return 'ERR:PostKey Not Found'
    PostKey = tmp[0]
    print('PostKey      = %s' % PostKey)
    tmp = re.findall("function "+varconst+".*?var.*?=(\[.*?])", script)
    if not tmp: return 'ERR:TabList Not Found'	
    TabList = tmp[0]
    TabList = varconst + "=" + TabList
    exec(TabList) in globals(), locals()
    main_tab = locals()[varconst]
    print(varconst+'          = %.90s...'%str(main_tab))
    decal(main_tab,step,step2,decal_fnc)
    print(varconst+'          = %.90s...'%str(main_tab))
    tmp = re.findall("\(\);(var .*?)\$\('\*'\)", script, re.S)
    if not tmp:
        tmp = re.findall("a0a\(\);(.*?)\$\('\*'\)", script, re.S)
        if not tmp:
            return 'ERR:List_Var Not Found'		
    List_Var = tmp[0]
    List_Var = re.sub("(function .*?}.*?})", "", List_Var)
    print('List_Var     = %.90s...' % List_Var)
    tmp = re.findall("(_[a-zA-z0-9]{4,8})=\[\]" , List_Var)
    if not tmp: return 'ERR:3Vars Not Found'
    _3Vars = tmp
    print('3Vars        = %s'%str(_3Vars))
    big_str_var = _3Vars[1]
    print('big_str_var  = %s'%big_str_var)    
    List_Var = List_Var.replace(',',';').split(';')
    for elm in List_Var:
        elm = elm.strip()
        if 'ismob' in elm: elm=''
        if '=[]'   in elm: elm = elm.replace('=[]','={}')
        elm = re.sub("(a0.\()", "a0d(main_tab,step2,", elm)
        #if 'a0G('  in elm: elm = elm.replace('a0G(','a0G(main_tab,step2,') 
        if elm!='':
            #print('elm = %s' % elm)
            elm = elm.replace('!![]','True');
            elm = elm.replace('![]','False');
            elm = elm.replace('var ','');
            #print('elm = %s' % elm)
            try:
                exec(elm)
            except:
                print('elm = %s' % elm)
                print('v = "%s" exec problem!' % elm, sys.exc_info()[0])            
    bigString = ''
    for i in range(0,len(locals()[_3Vars[2]])):
        if locals()[_3Vars[2]][i] in locals()[_3Vars[1]]:
            bigString = bigString + locals()[_3Vars[1]][locals()[_3Vars[2]][i]]	
    print('bigString    = %.90s...'%bigString) 
    tmp = re.findall('var b=\'/\'\+(.*?)(?:,|;)', script, re.S)
    if not tmp: return 'ERR:GetUrl Not Found'
    GetUrl = str(tmp[0])
    print('GetUrl       = %s' % GetUrl)    
    tmp = re.findall('(_.*?)\[', GetUrl, re.S)
    if not tmp: return 'ERR:GetVar Not Found'
    GetVar = tmp[0]
    print('GetVar       = %s' % GetVar)
    GetVal = locals()[GetVar][0]
    GetVal = atob(GetVal)
    print('GetVal       = %s' % GetVal)
    tmp = re.findall('}var (f=.*?);', script, re.S)        
    if not tmp: return 'ERR:PostUrl Not Found'
    PostUrl = str(tmp[0])
    print('PostUrl      = %s' % PostUrl)
    PostUrl = re.sub("(window\[.*?\])", "atob", PostUrl)        
    PostUrl = re.sub("([A-Z]{1,2}\()", "a0d(main_tab,step2,", PostUrl)    
    PostUrl = 'global f; '+PostUrl
    exec(PostUrl)
    return(['/'+GetVal,f+bigString,{ PostKey : 'ok'}])

def atob(elm):
    try:
        ret = base64.b64decode(elm)
    except:
        try:
            ret = base64.b64decode(elm+'=')
        except:
            try:
                ret = base64.b64decode(elm+'==')
            except:
                ret = 'ERR:base64 decode error'
    return ret.decode()
  
def parseInt(sin):
  m = re.search(r'^(\d+)[.,]?\d*?', str(sin))
  return int(m.groups()[-1]) if m and not callable(sin) else 0
def x(main_tab,step2,a):
    return(a0d(main_tab,step2,a))
def a0d(main_tab,step2,a):
    a = a - step2
    if a<0:
        c = 'undefined'
    else:
        c = main_tab[a]
    return c
  