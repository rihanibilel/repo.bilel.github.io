# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from errno import ESTALE
from hashlib import new
from imp import source_from_cache

from codequick import Route, Resolver, Listitem
import urlquick

SITE='https://akwam.in/'

@Route.register
def initAkoam(plugin, content_type="video"):
   yield Listitem.recent(recent_videos, url=SITE+"/one1")
   yield Listitem.search(search_videos)
   
   art = 'https://i.pinimg.com/736x/ca/bf/a8/cabfa8c188d16ecda76a846ec98efb23.jpg'
   
   item = {"label": "Films", "art": {"thumb":art}, "callback": getInitfilm}
   yield Listitem.from_dict(**item)

   item = {"label": "Series", "art": {"thumb": art}, "callback": getInitSeries}
   yield Listitem.from_dict(**item)
   item = {"label": "عربي Films", "art": {"thumb":art}, "callback": getInitfilm, "params":{"lang": "arabic"}}
   yield Listitem.from_dict(**item)
   
   item = {"label": "عربي Series", "art": {"thumb": art}, "callback": getInitSeries, "params":{"lang": "arabic"}}
   yield Listitem.from_dict(**item)


@Route.register
def search_videos(plugin, search_query):
    url = (SITE + "/search?q={}".format(search_query))
    return video_list(plugin, url)


@Route.register
def video_list(_, url, filter_mode=0):
    resp = urlquick.get(url)
    resp.encoding = resp.apparent_encoding
    filmListRoot = resp.parse("div", attrs={"class":"widget-body row flex-wrap"})
    filmLinks = filmListRoot.iterfind("div/div/div/a")
    
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("picture/img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("data-src")
            item.art.fanart = image.get("data-src")
            if link.get("href").__contains__('series'):
                item.set_callback(getSeriesEpisodes,tempLink)
            else:
                item.set_callback(getFilmResolution,tempLink, item.label)
            yield item

@Route.register
def recent_videos(_, url, filter_mode=0):
    resp = urlquick.get(url)
    resp.encoding = resp.apparent_encoding
    filmListRoot = resp.parse("div", attrs={"class":"swiper-container"})
    filmLinks = filmListRoot.iterfind("div/div/div")
    for link in filmLinks :
        item = Listitem()
        tempImages = link.iterfind("div/a/picture/img") #GET ART
        for image in tempImages:
            item.art.thumb = image.get("src") 
            item.art.fanart = image.get("src") 
        ha = link.iterfind("div/h3/a")
        for h in ha :
            item.label = h.text
            if h.get("href").__contains__('series'):
                item.set_callback(getSeriesEpisodes,h.get("href"))
            else:
                item.set_callback(getFilmResolution,h.get("href"), item.label)
            yield item

@Route.register
def getInitfilm(plugin, content_type="video", lang=None):
    
    if (lang=="arabic"):
        resp = urlquick.get(SITE +"/movies?language=1", max_age=-1)
    else:
        resp = urlquick.get(SITE +"/movies", max_age=-1)
    resp.encoding = resp.apparent_encoding
    filmListRoot = resp.parse("div", attrs={"class":"widget-body row flex-wrap"})
    filmLinks = filmListRoot.iterfind("div/div/div/a")
    
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("picture/img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("data-src")
            item.art.fanart = image.get("data-src")
            item.set_callback(getFilmResolution,tempLink,item.label)
            yield item

    NextPageTree = resp.parse("ul", attrs={"class":"pagination justify-content-center"})
    nextPageP = NextPageTree.find("li[@class='page-item mx-1']/a")
    yield Listitem.next_page(nextPage=nextPageP.get("href"),callback=getFilm)

@Route.register
def getFilm(plugin, nextPage):
    resp = urlquick.get(nextPage, max_age=-1)
    resp.encoding = resp.apparent_encoding
    filmListRoot = resp.parse("div", attrs={"class":"widget-body row flex-wrap"})
    filmLinks = filmListRoot.iterfind("div/div/div/a")
    
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("picture/img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("data-src")
            item.art.fanart = image.get("data-src")
            item.set_callback(getFilmResolution,tempLink)
            yield item

    NextPageTree = resp.parse("ul", attrs={"class":"pagination justify-content-center"})
    nextPageP = NextPageTree.find("li[@class='page-item mx-1']/a")
    yield Listitem.next_page(nextPage=nextPageP.get("href"),callback=getFilm)

@Resolver.register
def getFilmResolution(plugin, url, title):
    resp = urlquick.get(url, max_age=-1)
    resp.encoding = resp.apparent_encoding
    resolutionListRoot = resp.parse("div", attrs={"class":"tab-content quality"})
    resolutionsList = resolutionListRoot.iterfind("div/div/div/a")
    resArray = []
    
    for res in resolutionsList:
        if res.get("href").__contains__('watch'):
            resArray.append(res.get("href"))
    
    baseUrl = url.split("movie/")[0]
    idmovie = resArray[0].split("watch/")[1] 
    baseUrl = baseUrl + "/watch/"+ idmovie + "/" + url.split("movie/")[1]
    resp2 = urlquick.get(baseUrl, max_age=-1)
    resp.encoding = resp.apparent_encoding
    videoRoot = resp2.parse("video", attrs={"id":"player"})
    videoList = videoRoot.iterfind("source")
    links = []
    for vid in videoList :
        tempLink = vid.get("src").replace('https://', 'http://')
        item = {"label": vid.get("size"), "link": tempLink, "name": title}
        links.append(item)

    import xbmcgui
    result = xbmcgui.Dialog().select('Choose the resolution', [source["label"] if source else 'Uknown' for source in links])
    url = links[result]["link"]
    return Listitem().from_dict(**{
        "label" : "Playing:" + links[result]["name"],
        "callback": url
    })

@Route.register
def getInitSeries(plugin, content_type="video", lang=None):
    if (lang == "arabic"):
        resp = urlquick.get(SITE + "/series?language=1", max_age=-1)
    else:
        resp = urlquick.get(SITE + "/series", max_age=-1)
    
    #import web_pdb;web_pdb.set_trace()
    resp.encoding = resp.apparent_encoding
    #resp = resp.content.decode("utf-8")
    filmListRoot = resp.parse("div", attrs={"class":"widget-body row flex-wrap"})
    filmLinks = filmListRoot.iterfind("div/div/div/a")
   
    
    for link in filmLinks :
        #tags = list({elem.tag for elem in link.iter()})
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("picture/img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("data-src")
            item.art.fanart = image.get("data-src")
            item.set_callback(getSeriesEpisodes,tempLink)
            yield item

    NextPageTree = resp.parse("ul", attrs={"class":"pagination justify-content-center"})
    nextPageP = NextPageTree.find("li[@class='page-item mx-1']/a")
    yield Listitem.next_page(nextPage=nextPageP.get("href"),callback=getSeries)

@Route.register
def getSeries(plugin, nextPage):
    resp = urlquick.get(nextPage, max_age=-1)
    resp.encoding = resp.apparent_encoding
    filmListRoot = resp.parse("div", attrs={"class":"widget-body row flex-wrap"})
    filmLinks = filmListRoot.iterfind("div/div/div/a")
    
    
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("picture/img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("data-src")
            item.art.fanart = image.get("data-src")
            item.set_callback(getSeriesEpisodes,tempLink)
            yield item

    NextPageTree = resp.parse("ul", attrs={"class":"pagination justify-content-center"})
    nextPageP = NextPageTree.find("li[@class='page-item mx-1']/a")
    yield Listitem.next_page(nextPage=nextPageP.get("href"),callback=getSeries)

@Route.register
def getSeriesEpisodes(plugin, url):
    resp = urlquick.get(url, max_age=-1)
    resp.encoding = resp.apparent_encoding
    episodeListRoot = resp.parse("div", attrs={"class":"row"})
    episodes = episodeListRoot.iterfind("div/div/div/a")
    for link in episodes :
        item = Listitem()
        tempLink = link.get("href")
        tempImages = link.iterfind("picture/img")
        for image in tempImages:
            item.label = image.get("alt")
            item.art.thumb = image.get("src")
            item.art.fanart = image.get("src")
            item.set_callback(getSeriesResolution,tempLink,item.label)
            yield item

@Resolver.register
def getSeriesResolution(plugin, url, title):
    resp = urlquick.get(url, max_age=-1)
    resp.encoding = resp.apparent_encoding
    resolutionListRoot = resp.parse("div", attrs={"class":"tab-content quality"})
    resolutionsList = resolutionListRoot.iterfind("div/div/div/a")
    resArray = []
    
    for res in resolutionsList:
        if res.get("href").__contains__('watch'):
            resArray.append(res.get("href"))
    
    baseUrl = url.split("episode/")[0] 
    idmovie = resArray[0].split("watch/")[1] 
    baseUrl = baseUrl + "/watch/"+ idmovie + "/" + url.split("episode/")[1]
    resp2 = urlquick.get(baseUrl, max_age=-1)
    resp.encoding = resp.apparent_encoding
    
    videoRoot = resp2.parse("video", attrs={"id":"player"})
    videoList = videoRoot.iterfind("source")
    links = []
    for vid in videoList :
        tempLink = vid.get("src").replace('https://', 'http://')
        item = {"label": vid.get("size"), "link": tempLink, "name": title}
        links.append(item)

    import xbmcgui
    result = xbmcgui.Dialog().select('Choose the resolution', [source["label"] if source else 'Uknown' for source in links])
    url = links[result]["link"]
    return Listitem().from_dict(**{
        "label" : "Playing:" + links[result]["name"],
        "callback": url
    })



def playFilmVideo(plugin, url):
    #import web_pdb;web_pdb.set_trace()
    return plugin.extract_source(url, quality=3)


    return Listitem().from_dict(**{
        "label" : "Playing:" + name,
        "callback": url
    })