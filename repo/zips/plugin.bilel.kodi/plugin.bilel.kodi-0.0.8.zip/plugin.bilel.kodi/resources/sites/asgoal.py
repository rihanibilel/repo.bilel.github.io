﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from hashlib import new
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.parser import cParser

import requests
sgn = requests.Session()

from codequick import Route, Resolver, Listitem
import urlquick

SITE= 'https://www.as-goal.com/mm'
SITE_NAME = 'asgoal'

@Route.register
def init_asgoal(plugin, content_type="segment"):
    oRequestHandler = cRequestHandler(SITE)
    sHtmlContent = oRequestHandler.request()

    oParser = cParser()
    sStart = '<div id="Today" class='
    sEnd ='<div id="Tomorrow" class='
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
 
    # ([^<]+) .+? (.+?)

    sPattern = '<a href="(.+?)".+?rel="(.+?)">.+?<img alt="(.+?)" title.+?<img alt="(.+?)" title='



    aResult = oParser.parse(sHtmlContent, sPattern)


    if (aResult[0] == True):
        total = len(aResult[1])
        for aEntry in aResult[1]:


            sTitle = aEntry[2] + ' - ' + aEntry[3] +  '  :GMT+2 ' +  aEntry[1] 
            sThumbnail = ""
            siteUrl = aEntry[0]
            if siteUrl.startswith('//'):
                siteUrl = 'http:' + aEntry[0]
            item = Listitem()
            item.label = sTitle
            #item.info = aEntry[1]
            #item.context = aEntry[1]
            item.art.thumb = sThumbnail
            item.art.fanart = sThumbnail
            item.set_callback(extract_source,siteUrl,item.label)
            yield item
        
  


@Resolver.register
def extract_source(plugin, url, title):
    
   
    oRequestHandler = cRequestHandler(url)
    sHtmlContent = oRequestHandler.request()
    # (.+?) # ([^<]+) .+? 
    sPattern = 'setURL([^<]+)">([^<]+)</button>'
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    links = []
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            sTitle = aEntry[1]
            siteUrl = aEntry[0].replace("('","").replace("')","")
            item = {"label": sTitle, "link": siteUrl, "name": title}
            links.append(item)
            
    import xbmcgui
    result = xbmcgui.Dialog().select('Choose source :', [source["label"] if source else 'Uknown' for source in links])
    url = links[result]["link"]
        
            
    oRequestHandler = cRequestHandler(url)
    hdr = {'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0','Accept-Encoding' : 'gzip','referer' : 'https://live.as-goal.tv/'}
    St=requests.Session()
    sHtmlContent = St.get(url,headers=hdr)
    sHtmlContent = sHtmlContent.content
    oParser = cParser()
    
    
    #import web_pdb;web_pdb.set_trace()
    # (.+?) # ([^<]+) .+? 
    sPattern = "source: '(.+?)',"
    aResult = oParser.parse(sHtmlContent, sPattern)
    #print aResult

    if (aResult[0] == True):
        for aEntry in aResult[1]:
            
            url = aEntry
            sHosterUrl = url.replace("https://tv.as-goal.site/zurl.html?src=","")
            sMovieTitle = title
            
           

    # (.+?) # ([^<]+) .+? 
    sPattern = 'src="(.+?)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            
            url = aEntry
            sHosterUrl = url.replace("https://tv.as-goal.site/zurl.html?src=","")
            sMovieTitle = title
            
    # (.+?) # ([^<]+) .+? 
    sPattern = 'file:"(.+?)",'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            
            url = aEntry
            sHosterUrl = url.replace("https://tv.as-goal.site/zurl.html?src=","")
            sMovieTitle = title
            

 # (.+?) # ([^<]+) .+? 

    sPattern = 'onclick="([^<]+)" >.+?>([^<]+)</strong>'
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        for aEntry in aResult[1]:
            
            url = aEntry[0].replace("('",'').replace("')","").replace("update_frame","")
            url = url.split('?link=', 1)[1]
            if url.startswith('//'):
                url = 'http:' + url
            if '/embed/' in url:
                oRequestHandler = cRequestHandler(url)
                oParser = cParser()
                sPattern =  'src="(.+?)" scrolling="no">'
                aResult = oParser.parse(url,sPattern)
                if (aResult[0] == True):
                   url = aResult[1][0]
 
            sHosterUrl = url.replace("https://tv.as-goal.site/zurl.html?src=","")
            sMovieTitle = str(aEntry[1])


 # (.+?) # ([^<]+) .+? 

    sPattern = 'src="(.+?)" width="(.+?)"'
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        for aEntry in aResult[1]:
            
            url = aEntry[0]
            if url.startswith('//'):
                url = 'http:' + url
            if 'xyz' in url:
                oRequestHandler = cRequestHandler(url)
                oRequestHandler.setRequestType(1)
                oRequestHandler.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0')
                oRequestHandler.addHeaderEntry('referer', 'https://memotec.xyz/')
                sHtmlContent2 = oRequestHandler.request()
                oParser = cParser()
                sPattern =  '(http[^<]+m3u8)'
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                   url = aResult[1][0]+ '|User-Agent=' + 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0' +'&Referer=' + "https://memotec.xyz/"
 
            sHosterUrl = url.replace("https://tv.as-goal.site/zurl.html?src=","") 
            sMovieTitle = title
            

    return Listitem().from_dict(**{
        "label" : "Playing:" + title,
        "callback": sHosterUrl
    })
    return plugin.extract_source(sHosterUrl)
