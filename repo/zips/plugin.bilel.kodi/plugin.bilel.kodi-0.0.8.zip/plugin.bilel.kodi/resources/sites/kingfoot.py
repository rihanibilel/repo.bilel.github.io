﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from hashlib import new
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.parser import cParser

import urllib.parse as urllib
import requests,re
sgn = requests.Session()

from codequick import Route, Resolver, Listitem
import urlquick

SITE= 'https://king-shoot.tv/today-matches/'
SITE_NAME = 'kingfoot'

@Route.register
def init_kingfoot(plugin, content_type="segment"):
    oRequestHandler = cRequestHandler(SITE)
    sHtmlContent = oRequestHandler.request()
    oParser = cParser()
            
    from datetime import date
    today = str(date.today())

# ([^<]+) .+? (.+?)
    s = requests.Session()            
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
							'Referer': urllib.quote(SITE)}
    r = s.get('https://web-api.golato.net/webapi/matches/'+today, headers=headers)
    sHtmlContent = r.content.decode('utf8')
    sPattern = '"id":"(.+?)","sitemap":1,"api_matche_id":"(.+?)",.+?,"home_en":"(.+?)",.+?,"away_en":"(.+?)",'


    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
	
	
    if (aResult[0] == True):
        total = len(aResult[1])
        for aEntry in aResult[1]:
            sTitle =  aEntry[2] +' - '+ aEntry[3]
            sThumbnail = ""
            siteUrl =  "https://king-shoot.tv/gen-matche/"+aEntry[0]+'/'+aEntry[1]
            sInfo = ''
			
            item = Listitem()
            item.label = sTitle
            item.art.thumb = sThumbnail
            item.art.fanart = sThumbnail
            murl=aEntry[0]
            item.set_callback(extract_source,siteUrl,item.label,murl)
            yield item

@Resolver.register
def extract_source(plugin, url, title, murl):
        
    oRequestHandler = cRequestHandler(url)
    hdr = {'User-Agent' : 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Mobile Safari/537.36','Origin' : '1xnews.online'}
    rurl = 'https://1xnews.online/home/matche/'+murl 
    St=requests.Session()              
    sHtmlContent = St.get(rurl,headers=hdr).content.decode('utf-8')
    oParser = cParser()
            
    sPattern =  "&k=(.+?)'" 
    mk =  '' 
    aResult = oParser.parse(sHtmlContent,sPattern)
    if (aResult[0] == True):
        mk = aResult[1][0] 

    sPattern = '"link":"(.+?)",.+?"server_name":"(.+?)",'
    aResult = oParser.parse(sHtmlContent, sPattern)
    links = []
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            sMovieTitle = aEntry[1]
            
            if mk:
               url = aEntry[0]+"&k="+mk
            if '.php?' in url:
                oRequestHandler = cRequestHandler(url)
                hdr = {'User-Agent' : 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Mobile Safari/537.36','Origin' : 'dalbouh.club','referer' : 'https://golato.tv/'}
                data = {'watch':'1'}
                St=requests.Session()
                sHtmlContent = St.get(url,headers=hdr)
                sHtmlContent2 = sHtmlContent.content
                oParser = cParser()
                sPattern =  'src="(.+?)"'
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                   url = aResult[1][0]
                sPattern =  '(http[^<]+m3u8)'
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                   url = aResult[1][0]
                oParser = cParser()
                sPattern =  'source: "(.+?)",'
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                   url = aResult[1][0]
            if 'embed' in url:
                oRequestHandler = cRequestHandler(url)
                sHtmlContent2 = St.get(url).content
                oParser = cParser()
                sPattern =  'src="(.+?)" scrolling="no">'
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                   url = aResult[1][0]
            if 'multi.html' in url:
                url2 = url.split('=') 
                live = url2[1].replace("&ch","")
                ch = url2[2]
                oRequestHandler = cRequestHandler(url)
                sHtmlContent2 = St.get(url).content
                oParser = cParser()
                sPattern =  "var src = (.+?),"
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                    url2 = aResult[1][0].split('hls:')
                    url2 = url2[1].split('+')
                    url2 = url2[0].replace("'","")
                    url = url2+live+'/'+ch+'.m3u8'
            if '/dash/' in url:
                oRequestHandler = cRequestHandler(url)
                sHtmlContent4 = St.get(url).content
                regx = '''var s = '(.+?)';.+?url="(.+?)".+?s;'''
                var = re.findall(regx,sHtmlContent4,re.S)
                if var:
                   a = var[0][0]
                   a = a.replace('\\','')
                   b = var[0][1]
                   url = 'https://video-a-sjc.xx.fbcdn.net/hvideo-ash66'+a
            sHosterUrl = url+ '|User-Agent=' + "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36" + '&Referer=' + 'https://king-shoot.com/'
            

            item = {"label": sMovieTitle, "link": sHosterUrl, "name": sMovieTitle}
            links.append(item)  

    sPattern = "'link': u'(.+?)',"
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            
            url = aEntry
            if '.php?' in url:
                oRequestHandler = cRequestHandler(url)
                sHtmlContent2 = St.get(url).content
                oParser = cParser()
                sPattern =  'source: "(.+?)",'
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                   url = aResult[1][0]
            if 'embed' in url:
                oRequestHandler = cRequestHandler(url)
                sHtmlContent2 = St.get(url).content
                oParser = cParser()
                sPattern =  'src="(.+?)" scrolling="no">'
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                   url = aResult[1][0]
            if 'multi.html' in url:
                url2 = url.split('=') 
                live = url2[1].replace("&ch","")
                ch = url2[2]
                oRequestHandler = cRequestHandler(url)
                sHtmlContent2 = St.get(url).content
                oParser = cParser()
                sPattern =  "var src = (.+?),"
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if (aResult[0] == True):
                    url2 = aResult[1][0].split('hls:')
                    url2 = url2[1].split('+')
                    url2 = url2[0].replace("'","")
                    url = url2+live+'/'+ch+'.m3u8'
            if '/dash/' in url:
                oRequestHandler = cRequestHandler(url)
                sHtmlContent4 = St.get(url).content
                regx = '''var s = '(.+?)';.+?url="(.+?)".+?s;'''
                var = re.findall(regx,sHtmlContent4,re.S)
                if var:
                   a = var[0][0]
                   a = a.replace('\\','')
                   b = var[0][1]
                   url = 'https://video-a-sjc.xx.fbcdn.net/hvideo-ash66'+a
            sHosterUrl = url+ '|User-Agent=' + "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36" + '&Referer=' + 'https://king-shoot.com/'
            sMovieTitle = 'link'
            

            item = {"label": sMovieTitle, "link": sHosterUrl, "name": sMovieTitle}
            links.append(item)  

    
    import xbmcgui
    result = xbmcgui.Dialog().select('Choose source :', [source["label"] if source else 'Uknown' for source in links])
    url = links[result]["link"]
    return Listitem().from_dict(**{
        "label" : "Playing:" + links[result]["name"],
        "callback": url
    })
    return plugin.extract_source(sHosterUrl)
