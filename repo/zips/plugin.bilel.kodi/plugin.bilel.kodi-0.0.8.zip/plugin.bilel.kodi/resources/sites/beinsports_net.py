﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from hashlib import new
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.parser import cParser

import requests
sgn = requests.Session()

from codequick import Route, Resolver, Listitem
import urlquick

SITE= 'http://www.beinsports.com'
SITE_NAME = 'beinsports'
PREMIER_LEAGUE = 'https://www.beinsports.com/ar/videos?categories%5B0%5D=%D8%A7%D9%84%D8%AF%D9%88%D8%B1%D9%8A-%D8%A7%D9%84%D8%A5%D9%86%D9%83%D9%84%D9%8A%D8%B2%D9%8A-%D8%A7%D9%84%D9%85%D9%85%D8%AA%D8%A7%D8%B2&tags%5B0%5D=%D8%A7%D9%84%D9%85%D9%84%D8%AE%D8%B5%D8%A7%D8%AA'
CHAMPIONS_LEAGUE = 'https://www.beinsports.com/ar/videos?categories%5B0%5D=%D8%AF%D9%88%D8%B1%D9%8A-%D8%A3%D8%A8%D8%B7%D8%A7%D9%84-%D8%A3%D9%88%D8%B1%D9%88%D8%A8%D8%A7&tags%5B0%5D=%D8%A7%D9%84%D9%85%D9%84%D8%AE%D8%B5%D8%A7%D8%AA'
LIGA = 'https://www.beinsports.com/ar/videos?categories%5B0%5D=%D8%A7%D9%84%D8%AF%D9%88%D8%B1%D9%8A-%D8%A7%D9%84%D8%A5%D8%B3%D8%A8%D8%A7%D9%86%D9%8A&tags%5B0%5D=%D8%A7%D9%84%D9%85%D9%84%D8%AE%D8%B5%D8%A7%D8%AA'
LIGUE1= 'https://www.beinsports.com/ar/videos?categories%5B0%5D=%D8%A7%D9%84%D8%AF%D9%88%D8%B1%D9%8A-%D8%A7%D9%84%D9%81%D8%B1%D9%86%D8%B3%D9%8A&tags%5B0%5D=%D8%A7%D9%84%D9%85%D9%84%D8%AE%D8%B5%D8%A7%D8%AA'
SERIEA = 'https://www.beinsports.com/ar/videos?categories%5B0%5D=%D8%A7%D9%84%D8%AF%D9%88%D8%B1%D9%8A-%D8%A7%D9%84%D8%A5%D9%8A%D8%B7%D8%A7%D9%84%D9%8A&tags%5B0%5D=%D8%A7%D9%84%D9%85%D9%84%D8%AE%D8%B5%D8%A7%D8%AA'
AFRICA_CHAMPIONS_LEAGUE = 'https://www.beinsports.com/ar/%D8%AF%D9%88%D8%B1%D9%8A-%D8%A3%D8%A8%D8%B7%D8%A7%D9%84-%D8%A3%D9%81%D8%B1%D9%8A%D9%82%D9%8A%D8%A7/%D8%A7%D9%84%D9%81%D9%8A%D8%AF%D9%8A%D9%88'


@Route.register
def init_beinsport(plugin, content_type="segment"):

    art = 'https://images.beinsports.com/nP_77Lo41sQGe7wcm5D9932ODe0=/216x0/3019256-UEFA_ChampionsLeague.png'
    item = {"label": "دوري أبطال أوروبا", "art": {"thumb":art}, "callback": showTitles, "params":{"suburl":CHAMPIONS_LEAGUE}}
    yield Listitem.from_dict(**item)

    art = 'https://images.beinsports.com/pnqesftowICnSjav5AeP4HO9V8U=/216x0/3019257-PremierLeague.png'
    item = {"label": "الدوري الإنكليزي الممتاز", "art": {"thumb":art}, "callback": showTitles, "params":{"suburl":PREMIER_LEAGUE}}
    yield Listitem.from_dict(**item)

    art = 'https://images.beinsports.com/ANohfjMlu_bXdaMdtIXop20NoMc=/216x0/3019258-LaLiga.png'
    item = {"label": "الدوري-الإسباني", "art": {"thumb":art}, "callback": showTitles, "params":{"suburl":LIGA}}
    yield Listitem.from_dict(**item)
    
    art = 'https://images.beinsports.com/oqOopKkbJXSpFqZI4ZW6lYZnbDE=/216x0/3319575-ligue1-uber.png'
    item = {"label": "الدوري الفرنسي", "art": {"thumb":art}, "callback": showTitles, "params":{"suburl":LIGUE1}}
    yield Listitem.from_dict(**item)    

    art = 'https://th.bing.com/th/id/R.8a07d89f1a66b50cb13e9a18556423d3?rik=saWDLt%2fdIGEROQ&pid=ImgRaw&r=0'
    item = {"label": "دوري-أبطال-أفريقيا", "art": {"thumb":art}, "callback": showTitles2, "params":{"suburl":AFRICA_CHAMPIONS_LEAGUE}}
    yield Listitem.from_dict(**item)  
   
@Route.register
def showTitles(plugin, suburl=None):

    resp = urlquick.get(suburl)
    resp.encoding = resp.apparent_encoding
    a = resp.content
    filmListRoot = resp.parse("div", attrs={"class":"flex-container"})
    filmLinks = filmListRoot.iterfind("article/div/a")
    #import web_pdb;web_pdb.set_trace()
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        item.label = link.get("title")
        item.set_callback(extract_source,tempLink, item.label)
        tempImages = link.iterfind("img")
        for image in tempImages:
            item.art.thumb = image.get("data-src")
            item.art.fanart = image.get("data-src")
            
            yield item

@Route.register
def showTitles2(plugin, suburl=None):

    resp = urlquick.get(suburl)
    resp.encoding = resp.apparent_encoding
    a = resp.content
    filmListRoot = resp.parse("div", attrs={"class":"content-gallery ptl"})
    filmLinks = filmListRoot.iterfind("ul/li/figcaption/a")
    #import web_pdb;web_pdb.set_trace()
    for link in filmLinks :
        item = Listitem()
        tempLink = link.get("href")
        item.label = link.text
        item.set_callback(extract_source,tempLink, item.label)
        yield item

@Resolver.register
def extract_source(plugin, url, title):

    oRequestHandler = cRequestHandler(url)
    sHtmlContent = oRequestHandler.request();
                      
    sPattern = '<meta itemprop="embedURL" content="([^<]+)" />'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    #import web_pdb;web_pdb.set_trace()
    if (aResult[0] == True):
        for aEntry in aResult[1]:
            
            url = aEntry
            if url.startswith('//'):
                url = 'http:' + url
            if 'autoplay' not in url:
                url = url+'?autoplay=0+'
            
            sHosterUrl = url
               
    return plugin.extract_source(sHosterUrl, quality=3)

   
